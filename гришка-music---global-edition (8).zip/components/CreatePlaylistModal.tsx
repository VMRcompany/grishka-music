
import React, { useState } from 'react';
import { X, ImageIcon, Check, Globe, Lock } from 'lucide-react';
import { Translations, Theme, Playlist } from '../types';

interface CreatePlaylistModalProps {
  t: Translations;
  theme: Theme;
  onClose: () => void;
  onCreate: (playlist: Playlist) => void;
}

export const CreatePlaylistModal: React.FC<CreatePlaylistModalProps> = ({ t, theme, onClose, onCreate }) => {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState<string | null>(null);
  const [isPublic, setIsPublic] = useState(true);

  const handleIconChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => setIcon(ev.target?.result as string);
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newPlaylist: Playlist = {
      id: Date.now().toString(),
      name: name.trim(),
      icon: icon || undefined,
      isPublic,
      songs: [],
      createdAt: new Date().toISOString()
    };

    onCreate(newPlaylist);
  };

  const inputBg = theme === 'dark' ? 'bg-black border-white/10 text-white' : 'bg-gray-50 border-gray-200 text-gray-900';

  return (
    <div className="fixed inset-0 z-[250] bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
      <div className={`w-full max-w-md rounded-3xl overflow-hidden shadow-2xl ${
        theme === 'dark' ? 'bg-[#1a1a1a] border border-white/10' : 'bg-white'
      }`}>
        <div className="p-6 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-black uppercase tracking-tight">{t.createPlaylist}</h2>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/5 text-gray-400">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Icon Picker */}
            <div className="flex flex-col items-center">
              <div 
                className={`w-28 h-28 rounded-3xl border-2 border-dashed flex flex-col items-center justify-center relative overflow-hidden group cursor-pointer transition-all ${
                  icon ? 'border-blue-500' : 'border-gray-200 dark:border-white/10 hover:border-blue-500'
                }`}
                onClick={() => document.getElementById('playlist-icon-input')?.click()}
              >
                <input id="playlist-icon-input" type="file" accept="image/*" className="hidden" onChange={handleIconChange} />
                {icon ? (
                  <img src={icon} className="w-full h-full object-cover" alt="Playlist icon" />
                ) : (
                  <>
                    <ImageIcon size={28} className="text-gray-400 group-hover:text-blue-500" />
                    <span className="text-[10px] font-black text-gray-500 mt-2 uppercase">{t.playlistIcon}</span>
                  </>
                )}
              </div>
            </div>

            {/* Name Input */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-500 ml-1">{t.playlistName}</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="My Awesome Mix"
                className={`w-full p-4 rounded-xl border-2 outline-none font-bold transition-all focus:border-blue-500 ${inputBg}`}
                autoFocus
              />
            </div>

            {/* Visibility Toggle */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-500 ml-1">{t.visibility}</label>
              <div className="flex gap-2">
                <button 
                  type="button"
                  onClick={() => setIsPublic(true)}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-bold transition-all ${
                    isPublic ? 'bg-blue-600 border-blue-600 text-white' : 'bg-transparent border-gray-200 dark:border-white/10 text-gray-500'
                  }`}
                >
                  <Globe size={16} /> {t.public}
                </button>
                <button 
                  type="button"
                  onClick={() => setIsPublic(false)}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-bold transition-all ${
                    !isPublic ? 'bg-blue-600 border-blue-600 text-white' : 'bg-transparent border-gray-200 dark:border-white/10 text-gray-500'
                  }`}
                >
                  <Lock size={16} /> {t.private}
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <button 
                type="button"
                onClick={onClose}
                className="flex-1 py-4 font-black rounded-xl border-2 border-transparent text-gray-500 hover:bg-black/5 dark:hover:bg-white/5 transition-all"
              >
                {t.cancel}
              </button>
              <button 
                type="submit"
                disabled={!name.trim()}
                className="flex-1 py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-800 text-white font-black rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <Check size={18} strokeWidth={3} /> {t.create}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
