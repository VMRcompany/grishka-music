
import React from 'react';
import { X, Globe, Moon, Sun, Info } from 'lucide-react';
import { Translations, Language, Theme } from '../types';

interface SettingsProps {
  t: Translations;
  currentLang: Language;
  theme: Theme;
  onClose: () => void;
  onLanguageChange: (lang: Language) => void;
  onThemeChange: (theme: Theme) => void;
}

export const Settings: React.FC<SettingsProps & { user: any, onLogout: any }> = ({ t, currentLang, theme, onClose, onLanguageChange, onThemeChange }) => {
  return (
    <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className={`w-full max-w-md rounded-[40px] border shadow-2xl overflow-hidden transition-all ${
        theme === 'dark' ? 'bg-[#1a1a1a] border-white/10' : 'bg-white border-gray-200'
      }`}>
        <div className={`px-10 py-8 flex items-center justify-between border-b ${theme === 'dark' ? 'border-white/10' : 'border-gray-100'}`}>
          <h2 className={`text-2xl font-black ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{t.settings}</h2>
          <button onClick={onClose} className={`p-2 rounded-full transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-white hover:bg-white/5' : 'text-gray-400 hover:text-gray-900 hover:bg-gray-100'}`}>
            <X size={24} />
          </button>
        </div>

        <div className="p-10 space-y-10 max-h-[70vh] overflow-y-auto">
          {/* Platform Info */}
          <div className="space-y-4">
             <div className="flex items-center gap-3 text-blue-500">
               <Info size={20} />
               <span className="font-black text-xs uppercase tracking-[0.2em]">{t.account}</span>
             </div>
             <div className={`p-6 rounded-3xl ${theme === 'dark' ? 'bg-white/5' : 'bg-gray-50'}`}>
                <p className={`text-sm font-bold leading-relaxed ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  Гришка Music is an open global music platform. Upload, share, and discover the sound of the world without limits.
                </p>
             </div>
          </div>

          {/* Theme Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-yellow-500">
              {theme === 'dark' ? <Moon size={20} /> : <Sun size={20} />}
              <span className="font-black text-xs uppercase tracking-[0.2em]">{t.theme}</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
               <button 
                  onClick={() => onThemeChange('dark')}
                  className={`py-5 rounded-3xl border-2 transition-all text-sm font-black ${theme === 'dark' ? 'bg-blue-600 border-blue-600 text-white shadow-xl' : 'bg-gray-50 border-transparent text-gray-500 hover:border-gray-200'}`}
               >
                 {t.dark}
               </button>
               <button 
                  onClick={() => onThemeChange('light')}
                  className={`py-5 rounded-3xl border-2 transition-all text-sm font-black ${theme === 'light' ? 'bg-blue-600 border-blue-600 text-white shadow-xl' : 'bg-gray-50 border-transparent text-gray-500 hover:border-gray-200'}`}
               >
                 {t.light}
               </button>
            </div>
          </div>

          {/* Language Selection */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-red-500">
              <Globe size={20} />
              <span className="font-black text-xs uppercase tracking-[0.2em]">{t.language}</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { id: 'en', label: 'English' },
                { id: 'ru', label: 'Русский' }
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => onLanguageChange(lang.id as Language)}
                  className={`py-5 rounded-3xl border-2 transition-all text-sm font-black ${
                    currentLang === lang.id 
                      ? 'bg-blue-600 border-blue-600 text-white shadow-xl' 
                      : (theme === 'dark' ? 'bg-white/5 border-white/10 text-gray-400 hover:border-white/30' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-white shadow-sm')
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className={`p-8 border-t text-center ${theme === 'dark' ? 'bg-white/5 border-white/10 text-gray-500' : 'bg-gray-50 border-gray-100 text-gray-400'}`}>
           <p className="text-xs font-black tracking-widest uppercase">Гришка Music Global Platform</p>
        </div>
      </div>
    </div>
  );
};