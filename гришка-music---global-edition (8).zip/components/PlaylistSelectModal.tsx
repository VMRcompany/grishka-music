
import React from 'react';
import { X, ListMusic, Plus } from 'lucide-react';
import { Song, Playlist, Translations, Theme } from '../types';

interface PlaylistSelectModalProps {
  song: Song;
  playlists: Playlist[];
  t: Translations;
  theme: Theme;
  onClose: () => void;
  onSelect: (playlistId: string) => void;
  onCreateNew: () => void;
}

export const PlaylistSelectModal: React.FC<PlaylistSelectModalProps> = ({ song, playlists, t, theme, onClose, onSelect, onCreateNew }) => {
  return (
    <div className="fixed inset-0 z-[250] bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className={`w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl transition-all ${
        theme === 'dark' ? 'bg-[#1a1a1a] border border-white/10' : 'bg-white'
      }`}>
        <div className="p-6 space-y-4">
          <div className="flex justify-between items-center">
             <h2 className="text-lg font-black uppercase tracking-tight">{t.addToPlaylist}</h2>
             <button onClick={onClose} className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/5 text-gray-400">
               <X size={20} />
             </button>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/5 mb-4">
            <img src={song.coverUrl} className="w-12 h-12 rounded-lg object-cover" alt="" />
            <div className="min-w-0">
               <p className="font-bold text-sm truncate">{song.title}</p>
               <p className="text-xs text-gray-500 truncate">{song.artist}</p>
            </div>
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar pr-2">
            {playlists.length > 0 ? (
              playlists.map(p => (
                <button 
                  key={p.id}
                  onClick={() => onSelect(p.id)}
                  className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${
                    theme === 'dark' ? 'hover:bg-white/5 text-gray-300' : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500">
                    {p.icon ? <img src={p.icon} className="w-full h-full object-cover rounded-lg" /> : <ListMusic size={20} />}
                  </div>
                  <span className="font-bold text-sm text-left truncate flex-1">{p.name}</span>
                </button>
              ))
            ) : (
              <p className="text-center py-4 text-gray-500 text-sm font-medium">{t.emptyLibrary}</p>
            )}
          </div>

          <button 
            onClick={onCreateNew}
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl border-2 border-dashed border-gray-200 dark:border-white/10 text-gray-500 hover:border-blue-500 hover:text-blue-500 transition-all font-bold text-sm mt-2"
          >
            <Plus size={18} /> {t.createPlaylist}
          </button>
        </div>
      </div>
    </div>
  );
};
