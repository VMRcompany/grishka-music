
import React, { useState, useEffect, useRef } from 'react';
import { X, Mic, Music, Loader2 } from 'lucide-react';
import { Translations, Theme } from '../types';

interface VoiceSearchOverlayProps {
  t: Translations;
  theme: Theme;
  onClose: () => void;
  onSearchResult: (query: string) => void;
}

export const VoiceSearchOverlay: React.FC<VoiceSearchOverlayProps> = ({ t, theme, onClose, onSearchResult }) => {
  const [mode, setMode] = useState<'voice' | 'music'>('voice');
  const [isProcessing, setIsProcessing] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (mode === 'voice') {
      startVoiceRecognition();
    } else {
      if (recognitionRef.current) recognitionRef.current.stop();
      simulateMusicAnalysis();
    }

    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
    };
  }, [mode]);

  const startVoiceRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice search is not supported in your browser.");
      onClose();
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'ru-RU';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      onSearchResult(transcript);
      onClose();
    };

    recognition.onerror = () => {
      setIsProcessing(false);
    };

    recognition.onend = () => {
      if (!isProcessing) setIsProcessing(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const simulateMusicAnalysis = () => {
    setIsProcessing(true);
    // Simulate audio analysis duration
    setTimeout(() => {
      setIsProcessing(false);
      // For music search simulation
      onSearchResult("Phonk"); 
      onClose();
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-3xl flex flex-col items-center justify-center p-8 transition-all animate-in fade-in duration-300">
      <button 
        onClick={onClose} 
        className="absolute top-8 right-8 p-4 bg-white/5 hover:bg-white/10 rounded-full text-white transition-all group"
      >
        <X size={32} className="group-hover:rotate-90 transition-transform" />
      </button>

      <div className="flex flex-col items-center gap-16 max-w-lg w-full">
        <h2 className="text-white text-3xl font-black uppercase tracking-[0.2em] opacity-80 animate-pulse text-center leading-tight">
          {mode === 'voice' ? t.listening : t.analyzing}
        </h2>

        {/* Central Animation Zone */}
        <div className="relative flex items-center justify-center w-full">
          {/* Pulsating background rings */}
          <div className={`absolute w-72 h-72 rounded-full animate-ping opacity-10 border-[6px] ${mode === 'voice' ? 'border-blue-500' : 'border-purple-500'}`} style={{ animationDuration: '3s' }} />
          <div className={`absolute w-56 h-56 rounded-full animate-pulse opacity-30 border-4 ${mode === 'voice' ? 'border-blue-400' : 'border-purple-400'}`} />
          
          <div className={`w-36 h-36 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(37,99,235,0.3)] transition-all duration-700 ${
            mode === 'voice' ? 'bg-blue-600' : 'bg-purple-600'
          }`}>
            {mode === 'voice' ? (
              <Mic size={56} className="text-white" />
            ) : (
              <Music size={56} className="text-white" />
            )}
          </div>
        </div>

        <div className="flex flex-col items-center gap-6 w-full">
          <p className="text-white/60 text-lg font-bold tracking-wide">
            {mode === 'voice' ? t.searchByVoice : t.searchByMusic}
          </p>
          
          <button 
            onClick={() => setMode(mode === 'voice' ? 'music' : 'voice')}
            className={`px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-[0.3em] transition-all border-2 flex items-center gap-3 ${
              mode === 'voice' 
                ? 'border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white' 
                : 'border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white'
            }`}
          >
            {mode === 'voice' ? <Music size={16} /> : <Mic size={16} />}
            {mode === 'voice' ? t.searchByMusic : t.searchByVoice}
          </button>
        </div>
      </div>
    </div>
  );
};
