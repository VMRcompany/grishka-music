
import React from 'react';
import { Home, Compass, Library, Settings } from 'lucide-react';
import { Translations, Theme } from '../types';

interface MobileNavProps {
  t: Translations;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenSettings: () => void;
  theme: Theme;
}

export const MobileNav: React.FC<MobileNavProps> = ({ t, activeTab, setActiveTab, onOpenSettings, theme }) => {
  const bgColor = theme === 'dark' ? 'bg-[#000000]/95' : 'bg-white/95 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]';
  const textColor = (id: string) => activeTab === id ? (theme === 'dark' ? 'text-white' : 'text-blue-600') : 'text-gray-500';

  return (
    <div className={`md:hidden fixed bottom-0 left-0 right-0 h-20 ${bgColor} backdrop-blur-xl border-t ${theme === 'dark' ? 'border-white/10' : 'border-gray-100'} flex items-center justify-around px-6 z-[90] pb-safe`}>
      <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1.5 transition-colors ${textColor('home')}`}>
        <Home size={22} strokeWidth={activeTab === 'home' ? 3 : 2} />
        <span className="text-[10px] font-black uppercase tracking-wider">{t.home}</span>
      </button>
      <button onClick={() => setActiveTab('explore')} className={`flex flex-col items-center gap-1.5 transition-colors ${textColor('explore')}`}>
        <Compass size={22} strokeWidth={activeTab === 'explore' ? 3 : 2} />
        <span className="text-[10px] font-black uppercase tracking-wider">{t.explore}</span>
      </button>
      <button onClick={() => setActiveTab('library')} className={`flex flex-col items-center gap-1.5 transition-colors ${textColor('library')}`}>
        <Library size={22} strokeWidth={activeTab === 'library' ? 3 : 2} />
        <span className="text-[10px] font-black uppercase tracking-wider">{t.library}</span>
      </button>
      <button onClick={onOpenSettings} className={`flex flex-col items-center gap-1.5 transition-colors ${textColor('settings')}`}>
        <Settings size={22} strokeWidth={activeTab === 'settings' ? 3 : 2} />
        <span className="text-[10px] font-black uppercase tracking-wider">{t.settings}</span>
      </button>
    </div>
  );
};
