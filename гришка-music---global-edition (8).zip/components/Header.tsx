
import React from 'react';
import { Search, Settings, Moon, Sun, Mic } from 'lucide-react';
import { Translations, Theme } from '../types';

interface HeaderProps {
  t: Translations;
  theme: Theme;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onSearch: (query: string) => void;
  onOpenSettings: () => void;
  onToggleTheme: () => void;
  onOpenVoiceSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({ t, theme, searchQuery, setSearchQuery, onSearch, onOpenSettings, onToggleTheme, onOpenVoiceSearch }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    onSearch(val); // Instant trigger
  };

  return (
    <header className={`sticky top-0 z-50 backdrop-blur-3xl px-4 md:px-6 py-4 flex items-center justify-between gap-4 md:gap-8 transition-colors ${
      theme === 'dark' ? 'bg-[#030303]/80' : 'bg-white/80 border-b border-gray-100'
    }`}>
      <form onSubmit={handleSubmit} className="flex-1 max-w-2xl">
        <div className="relative group">
          <div className={`absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none transition-colors ${
            theme === 'dark' ? 'text-gray-400 group-focus-within:text-white' : 'text-gray-400 group-focus-within:text-blue-600'
          }`}>
            <Search size={20} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={handleChange}
            placeholder={t.searchPlaceholder}
            className={`w-full pl-12 pr-12 py-3 rounded-2xl outline-none border-none transition-all text-sm md:text-base font-bold ${
              theme === 'dark' 
                ? 'bg-white/10 text-white placeholder:text-gray-600 focus:bg-white/20' 
                : 'bg-gray-100 text-gray-900 border-gray-200 focus:bg-white shadow-sm'
            }`}
          />
          <button 
            type="button"
            onClick={onOpenVoiceSearch}
            className={`absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-blue-600 transition-all`}
          >
            <Mic size={20} />
          </button>
        </div>
      </form>

      <div className="flex items-center gap-1 md:gap-4">
        <button 
          onClick={onToggleTheme}
          className={`p-2 md:p-2.5 rounded-full transition-all ${
            theme === 'dark' ? 'text-gray-400 hover:text-yellow-400 hover:bg-white/5' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-100'
          }`}
        >
          {/* Fix: Replaced invalid md:size prop with responsive Tailwind classes to handle scaling across screen sizes */}
          {theme === 'dark' ? <Sun className="w-5 h-5 md:w-6 md:h-6" strokeWidth={2.5} /> : <Moon className="w-5 h-5 md:w-6 md:h-6" strokeWidth={2.5} />}
        </button>
        <button 
          onClick={onOpenSettings}
          className={`p-2 md:p-2.5 rounded-full transition-all ${
            theme === 'dark' ? 'text-gray-400 hover:text-white hover:bg-white/5' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-100'
          }`}
        >
          {/* Fix: Replaced invalid md:size prop with responsive Tailwind classes to handle scaling across screen sizes */}
          <Settings className="w-5 h-5 md:w-6 md:h-6" strokeWidth={2.5} />
        </button>
      </div>
    </header>
  );
};
