
import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* 
        PRECISE 3D TEXTURE REPLICA:
        This SVG recreates the glossy, 3D finish of the Messenger bubble with headphones.
        It uses nested gradients and filters to achieve the "texture" the user requested.
      */}
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-xl">
        <defs>
          {/* Main blue gradient for the bolt texture */}
          <linearGradient id="boltGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor:'#4ea1f1', stopOpacity:1}} />
            <stop offset="100%" style={{stopColor:'#0056b3', stopOpacity:1}} />
          </linearGradient>
          
          {/* Bevel and gloss effects */}
          <filter id="innerShadow">
            <feOffset dx="0" dy="2" />
            <feGaussianBlur stdDeviation="2" result="offset-blur" />
            <feComposite operator="out" in="SourceGraphic" in2="offset-blur" result="inverse" />
            <feFlood floodColor="black" floodOpacity="0.2" result="color" />
            <feComposite operator="in" in="color" in2="inverse" result="shadow" />
            <feComposite operator="over" in="shadow" in2="SourceGraphic" />
          </filter>

          <linearGradient id="glossGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{stopColor:'white', stopOpacity:0.8}} />
            <stop offset="50%" style={{stopColor:'white', stopOpacity:0}} />
          </linearGradient>
        </defs>

        {/* 3D White Bubble */}
        <path 
          d="M50 20C33.4 20 20 31.2 20 45C20 52.8 24.8 59.8 32 64L29 76L41 70C44 71 47 71.5 50 71.5C66.6 71.5 80 60.3 80 46.5C80 32.7 66.6 21.5 50 21.5Z" 
          fill="#f8fafc" 
          stroke="#e2e8f0"
          strokeWidth="0.5"
          filter="url(#innerShadow)"
        />
        
        {/* Gloss Overlay on Bubble */}
        <path 
          d="M50 25C38 25 28 32 28 40C28 42 29 44 31 46C35 40 42 35 50 35C58 35 65 40 69 46C71 44 72 42 72 40C72 32 62 25 50 25Z" 
          fill="url(#glossGrad)" 
          opacity="0.3"
        />

        {/* The Lightning Bolt with deep blue glossy texture */}
        <path 
          d="M58 36L42 51H51L43 66L59 51H50L58 36Z" 
          fill="url(#boltGradient)" 
          className="drop-shadow-md"
        />

        {/* 3D Headphones Wrap */}
        <path 
          d="M12 55C12 28 29 12 50 12C71 12 88 28 88 55" 
          fill="none" 
          stroke="#1e293b" 
          strokeWidth="7" 
          strokeLinecap="round" 
        />
        
        {/* Gloss on Headphone band */}
        <path 
          d="M20 30C30 20 40 18 50 18" 
          fill="none" 
          stroke="white" 
          strokeWidth="1.5" 
          strokeLinecap="round" 
          opacity="0.2" 
        />

        {/* Earcups with depth */}
        <rect x="8" y="48" width="12" height="20" rx="5" fill="#0f172a" />
        <rect x="11" y="52" width="6" height="12" rx="2" fill="#334155" />
        
        <rect x="80" y="48" width="12" height="20" rx="5" fill="#0f172a" />
        <rect x="83" y="52" width="6" height="12" rx="2" fill="#334155" />
      </svg>
    </div>
  );
};
