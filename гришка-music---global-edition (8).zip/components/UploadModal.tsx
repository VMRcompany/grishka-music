
import React, { useState } from 'react';
import { X, Upload, Check, ImageIcon, Loader2, Hash } from 'lucide-react';
import { Translations, Theme, Song } from '../types';

interface UploadModalProps {
  t: Translations;
  theme: Theme;
  onClose: () => void;
  onUpload: (song: Song) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({ t, theme, onClose, onUpload }) => {
  const [file, setFile] = useState<File | null>(null);
  const [cover, setCover] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [tags, setTags] = useState('');
  const [isPublishing, setIsPublishing] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0]);
      if (!title) setTitle(e.target.files[0].name.replace(/\.[^/.]+$/, ""));
    }
  };

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => setCover(ev.target?.result as string);
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || isPublishing) return;

    setIsPublishing(true);
    
    try {
      const audioData = await fileToBase64(file);
      const hashtagArray = tags.split(',').map(s => s.trim().replace('#', '')).filter(s => s !== '');
      
      const newSong: Song = {
        id: `global-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        title: title || 'Unnamed Track',
        artist: artist || 'Anonymous',
        album: 'Global Feed',
        coverUrl: cover || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400',
        duration: '3:20',
        durationSec: 200,
        audioUrl: audioData,
        isUserUploaded: true,
        tags: hashtagArray,
        publishedBy: 'User'
      };

      // Вызываем публикацию и закрываем окно без задержек
      onUpload(newSong);
      onClose();
      
    } catch (err) {
      console.error("Upload error:", err);
      setIsPublishing(false);
      alert("Error: File might be too large for browser storage.");
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
      <div className={`w-full max-w-xl rounded-[32px] overflow-hidden shadow-2xl transition-all ${
        theme === 'dark' ? 'bg-[#1a1a1a] border border-white/10' : 'bg-white'
      }`}>
        <div className="p-6 md:p-10 space-y-6 md:space-y-8">
          <div className="flex justify-between items-center">
            <h2 className={`text-xl md:text-3xl font-black uppercase tracking-tight ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{t.publish}</h2>
            {!isPublishing && (
              <button onClick={onClose} className={`p-2 rounded-full transition-colors ${theme === 'dark' ? 'text-gray-500 hover:text-white bg-white/5' : 'text-gray-400 hover:text-gray-900 bg-gray-100'}`}>
                <X size={24} />
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 md:space-y-8">
            <div className="flex flex-col sm:flex-row gap-6">
               <div 
                 className={`w-full sm:w-36 h-36 shrink-0 rounded-3xl border-2 border-dashed flex flex-col items-center justify-center relative overflow-hidden group cursor-pointer transition-all ${
                   cover ? 'border-blue-500' : 'border-gray-200 dark:border-white/10 hover:border-blue-500'
                 }`}
                 onClick={() => !isPublishing && document.getElementById('cover-input')?.click()}
               >
                 <input id="cover-input" type="file" accept="image/*" className="hidden" onChange={handleCoverChange} />
                 {cover ? (
                   <img src={cover} className="w-full h-full object-cover" />
                 ) : (
                   <>
                     <ImageIcon size={32} className="text-gray-400 group-hover:text-blue-500" />
                     <span className="text-[10px] font-black text-gray-500 mt-2 uppercase tracking-widest">{t.preview}</span>
                   </>
                 )}
               </div>

               <div 
                 className={`flex-1 min-h-[144px] border-2 border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all ${
                   file ? 'border-green-500 bg-green-500/5' : 'border-gray-200 dark:border-white/10 hover:border-blue-500'
                 }`} 
                 onClick={() => !isPublishing && document.getElementById('file-input')?.click()}
               >
                 <input id="file-input" type="file" accept="audio/*" className="hidden" onChange={handleFileChange} />
                 <Upload size={40} className={file ? 'text-green-500' : 'text-gray-400'} />
                 <p className="text-[11px] font-black mt-3 text-gray-500 uppercase tracking-[0.2em] max-w-[200px] truncate text-center px-4">
                   {file ? file.name : t.selectFile}
                 </p>
               </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input 
                  type="text" placeholder="Song Title" value={title} onChange={e => setTitle(e.target.value)} disabled={isPublishing}
                  className={`p-5 rounded-2xl border-2 outline-none font-bold transition-all text-sm ${theme === 'dark' ? 'bg-black border-white/5 text-white focus:border-blue-500' : 'bg-gray-50 border-gray-100 focus:bg-white focus:border-blue-500'}`}
                />
                <input 
                  type="text" placeholder="Artist Name" value={artist} onChange={e => setArtist(e.target.value)} disabled={isPublishing}
                  className={`p-5 rounded-2xl border-2 outline-none font-bold transition-all text-sm ${theme === 'dark' ? 'bg-black border-white/5 text-white focus:border-blue-500' : 'bg-gray-50 border-gray-100 focus:bg-white focus:border-blue-500'}`}
                />
              </div>
              <div className="relative">
                <Hash className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input 
                  type="text" placeholder={t.hashtags} value={tags} onChange={e => setTags(e.target.value)} disabled={isPublishing}
                  className={`w-full p-5 pl-14 rounded-2xl border-2 outline-none font-bold transition-all text-sm ${theme === 'dark' ? 'bg-black border-white/5 text-white focus:border-blue-500' : 'bg-gray-50 border-gray-100 focus:bg-white focus:border-blue-500'}`}
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={!file || isPublishing}
              className="w-full py-5 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-800 text-white font-black rounded-2xl transition-all shadow-xl flex items-center justify-center gap-4 text-lg active:scale-95"
            >
              {isPublishing ? <Loader2 className="animate-spin" size={24} /> : <Check size={24} strokeWidth={4} />}
              <span className="tracking-widest uppercase">{isPublishing ? 'PUBLISHING...' : t.publish}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
