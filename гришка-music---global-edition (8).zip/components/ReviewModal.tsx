
import React, { useState } from 'react';
import { X, Star, Send, User } from 'lucide-react';
import { Song, Translations, Theme } from '../types';

interface ReviewModalProps {
  song: Song;
  t: Translations;
  theme: Theme;
  onClose: () => void;
  onSubmitReview: (songId: string, rating: number, comment: string) => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({ song, t, theme, onClose, onSubmitReview }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');

  return (
    <div className="fixed inset-0 z-[150] bg-black/90 backdrop-blur-2xl flex items-center justify-center p-4">
      <div className={`w-full max-w-2xl rounded-[40px] overflow-hidden shadow-2xl transition-all ${
        theme === 'dark' ? 'bg-[#121212] border border-white/5' : 'bg-white border border-gray-200'
      }`}>
        <div className="flex h-[80vh]">
           {/* Song Sidebar */}
           <div className={`w-1/3 p-8 flex flex-col items-center gap-6 border-r ${theme === 'dark' ? 'border-white/5' : 'border-gray-100'}`}>
              <img src={song.coverUrl} className="w-full aspect-square object-cover rounded-[32px] shadow-2xl" />
              <div className="text-center">
                <h3 className={`font-black text-lg ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{song.title}</h3>
                <p className="text-gray-500 font-medium">{song.artist}</p>
              </div>
              <div className="flex items-center gap-2 bg-yellow-400/10 text-yellow-500 px-3 py-1.5 rounded-full font-black text-sm">
                <Star size={14} fill="currentColor" />
                {song.averageRating?.toFixed(1) || 'No ratings'}
              </div>
           </div>

           {/* Content Area */}
           <div className="flex-1 flex flex-col">
              <div className="p-6 flex justify-end">
                <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-gray-400">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-8 space-y-8 pb-8">
                {/* Existing Reviews */}
                <div className="space-y-4">
                  <h4 className="font-black uppercase tracking-widest text-xs text-gray-500">{t.reviews}</h4>
                  {(song.reviews && song.reviews.length > 0) ? (
                    song.reviews.map(rev => (
                      <div key={rev.id} className={`p-4 rounded-2xl ${theme === 'dark' ? 'bg-white/5' : 'bg-gray-50'}`}>
                        <div className="flex items-center gap-2 mb-2">
                           {rev.userAvatar ? <img src={rev.userAvatar} className="w-6 h-6 rounded-full" /> : <User size={16} />}
                           <span className="font-bold text-sm">{rev.userName}</span>
                           <div className="flex items-center text-yellow-400 ml-auto">
                             <Star size={10} fill="currentColor" />
                             <span className="text-[10px] ml-0.5 font-black">{rev.rating}</span>
                           </div>
                        </div>
                        <p className={`text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>{rev.comment}</p>
                        <span className="text-[10px] text-gray-500 mt-2 block">{rev.date}</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-sm italic">Be the first to share your thoughts!</p>
                  )}
                </div>

                {/* Submit New */}
                <div className={`p-6 rounded-[32px] space-y-6 ${theme === 'dark' ? 'bg-blue-600/5 border border-blue-500/10' : 'bg-blue-50'}`}>
                  <div className="flex flex-col items-center gap-3">
                    <div className="flex gap-1.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setRating(star)}
                          className="transition-transform active:scale-90"
                        >
                          <Star 
                            size={28} 
                            fill={(hoverRating || rating) >= star ? "#fbbf24" : "transparent"} 
                            className={(hoverRating || rating) >= star ? "text-yellow-400" : "text-gray-400"} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea 
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder={t.writeReview}
                    className={`w-full p-4 rounded-2xl resize-none outline-none border transition-all text-sm ${
                      theme === 'dark' ? 'bg-black/40 border-white/5 text-white' : 'bg-white border-gray-200'
                    }`}
                  />
                  <button
                    disabled={rating === 0}
                    onClick={() => {
                      onSubmitReview(song.id, rating, comment);
                      setComment('');
                      setRating(0);
                    }}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 text-white font-black rounded-2xl flex items-center justify-center gap-2 transition-all shadow-xl"
                  >
                    <Send size={16} />
                    {t.submit}
                  </button>
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
