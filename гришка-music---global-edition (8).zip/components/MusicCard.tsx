
import React from 'react';
import { Play, PlusCircle, MoreVertical, Download } from 'lucide-react';
import { Song, Theme } from '../types';

interface MusicCardProps {
  song: Song;
  onPlay: (song: Song) => void;
  onDownload: (song: Song) => void;
  onAddToPlaylist: (song: Song) => void;
  theme: Theme;
}

export const MusicCard: React.FC<MusicCardProps> = ({ song, onPlay, onDownload, onAddToPlaylist, theme }) => {
  return (
    <div 
      className={`group transition-all duration-200 relative flex items-center md:flex-col md:items-start gap-3 md:gap-0 p-2 md:p-3 rounded-xl md:rounded-[24px] ${
        theme === 'dark' 
          ? 'bg-transparent hover:bg-white/5' 
          : 'bg-transparent hover:bg-gray-100'
      }`}
    >
      <div 
        className="relative w-14 h-14 md:w-full md:aspect-square shrink-0 cursor-pointer overflow-hidden rounded-lg md:rounded-[20px] shadow-sm" 
        onClick={() => onPlay(song)}
      >
        <img 
          src={song.coverUrl} 
          alt={song.title} 
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-8 h-8 md:w-12 md:h-12 bg-blue-600 rounded-full flex items-center justify-center shadow-lg">
            <Play fill="white" size={24} className="ml-1" />
          </div>
        </div>
      </div>
      
      <div className="flex-1 min-w-0 md:mt-3 md:w-full">
        <div className="flex justify-between items-start gap-1">
          <div className="flex-1 min-w-0" onClick={() => onPlay(song)}>
            <h3 className={`font-bold truncate text-sm md:text-[15px] leading-tight ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {song.title}
            </h3>
            <p className={`text-[12px] md:text-sm font-medium truncate mt-0.5 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {song.artist}
            </p>
          </div>
          
          <div className="flex items-center gap-0.5">
             <button 
              onClick={(e) => {
                e.stopPropagation();
                onDownload(song);
              }}
              className={`p-1.5 rounded-full transition-all hover:bg-blue-500/10 ${theme === 'dark' ? 'text-gray-400 hover:text-green-500' : 'text-gray-400 hover:text-green-600'}`}
              title="Download"
            >
              <Download size={18} />
            </button>
             <button 
              onClick={(e) => {
                e.stopPropagation();
                onAddToPlaylist(song);
              }}
              className={`p-1.5 rounded-full transition-all hover:bg-blue-500/10 ${theme === 'dark' ? 'text-gray-400 hover:text-blue-500' : 'text-gray-400 hover:text-blue-600'}`}
              title="Add to Playlist"
            >
              <PlusCircle size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
