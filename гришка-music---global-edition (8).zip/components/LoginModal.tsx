
import React, { useState } from 'react';
import { X, ArrowRight, Loader2, CheckCircle } from 'lucide-react';
import { Translations, Theme } from '../types';

interface LoginModalProps {
  t: Translations;
  theme: Theme;
  onClose: () => void;
  onLogin: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ t, theme, onClose, onLogin }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');

  const handleNextStep = () => {
    if (step === 1) {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        setStep(2);
      }, 800);
    } else {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        setStep(3);
        setTimeout(onLogin, 1200);
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-3xl flex items-center justify-center p-4">
      <div className={`w-full max-w-sm rounded-[40px] overflow-hidden shadow-2xl transition-all duration-500 transform scale-100 ${
        theme === 'dark' ? 'bg-[#121212] border border-white/10' : 'bg-white'
      }`}>
        <div className="p-8 space-y-8">
          <div className="flex justify-between items-center">
            <h2 className={`text-2xl font-black tracking-tight ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {step === 3 ? 'Успешно' : 'Yandex ID'}
            </h2>
            <button onClick={onClose} className="p-2 text-gray-400 hover:text-white bg-white/5 rounded-full transition-colors">
              <X size={24} />
            </button>
          </div>

          <div className="min-h-[200px] flex flex-col justify-center">
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="text-center">
                  <span className="text-6xl font-black italic text-red-600 select-none">Я</span>
                  <p className={`mt-4 font-bold ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>Введите ваш логин или почту</p>
                </div>
                <input 
                  type="text" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@yandex.ru"
                  className={`w-full p-4 rounded-2xl outline-none font-bold ${
                    theme === 'dark' ? 'bg-black text-white border border-white/10' : 'bg-gray-100'
                  }`}
                />
                <button 
                  onClick={handleNextStep}
                  disabled={!email || loading}
                  className="w-full py-5 bg-[#FF0000] text-white font-black rounded-[24px] hover:opacity-90 transition-all flex items-center justify-center gap-3"
                >
                  {loading ? <Loader2 className="animate-spin" /> : <>Далее <ArrowRight size={20} /></>}
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="text-center">
                  <p className="text-sm font-bold text-gray-500 mb-1">{email}</p>
                  <p className={`font-black text-xl ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>Введите пароль</p>
                </div>
                <input 
                  type="password" 
                  placeholder="••••••••"
                  className={`w-full p-4 rounded-2xl outline-none font-bold ${
                    theme === 'dark' ? 'bg-black text-white border border-white/10' : 'bg-gray-100'
                  }`}
                />
                <button 
                  onClick={handleNextStep}
                  disabled={loading}
                  className="w-full py-5 bg-[#FF0000] text-white font-black rounded-[24px] hover:opacity-90 transition-all flex items-center justify-center gap-3"
                >
                  {loading ? <Loader2 className="animate-spin" /> : 'Войти'}
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="flex flex-col items-center justify-center space-y-4 animate-in zoom-in duration-500">
                <CheckCircle size={80} className="text-green-500" />
                <p className={`font-black text-center ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Вход выполнен! <br/> Перенаправляем на Гришка Music...
                </p>
              </div>
            )}
          </div>
          
          <div className="pt-4 text-center">
            <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em] font-bold">
              Secure Authentication Sequence
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
