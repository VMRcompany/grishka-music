
import React, { useState, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Maximize2, Minimize2, Repeat, Repeat1, Shuffle, Download } from 'lucide-react';
import { Song, RepeatMode, Theme } from '../types';

interface PlayerProps {
  currentSong: Song | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onDownload: () => void;
  onNext: () => void;
  onBack: () => void;
  repeatMode: RepeatMode;
  onToggleRepeat: () => void;
  isShuffle: boolean;
  onToggleShuffle: () => void;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  theme: Theme;
}

export const Player: React.FC<PlayerProps> = ({ 
  currentSong, isPlaying, onTogglePlay, onDownload, onNext, onBack, 
  repeatMode, onToggleRepeat, isShuffle, onToggleShuffle,
  audioRef, theme 
}) => {
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [prevVolume, setPrevVolume] = useState(80);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const updateProgress = () => {
      setCurrentTime(audio.currentTime);
      setDuration(audio.duration || currentSong?.durationSec || 0);
    };
    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('loadedmetadata', updateProgress);
    return () => {
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('loadedmetadata', updateProgress);
    };
  }, [audioRef, currentSong]);

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (audioRef.current) {
      const newTime = parseFloat(e.target.value);
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      if (isMuted) {
        const restoreVol = prevVolume === 0 ? 80 : prevVolume;
        audioRef.current.volume = restoreVol / 100;
        setVolume(restoreVol);
        setIsMuted(false);
      } else {
        setPrevVolume(volume);
        audioRef.current.volume = 0;
        setVolume(0);
        setIsMuted(true);
      }
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    setVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val / 100;
      setIsMuted(val === 0);
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!currentSong) return null;

  const textColor = theme === 'dark' ? 'text-white' : 'text-gray-900';
  const bgColor = theme === 'dark' ? 'bg-[#0a0a0a]/98' : 'bg-white/98 shadow-2xl';
  const borderColor = theme === 'dark' ? 'border-white/10' : 'border-gray-200';

  return (
    <div className={`fixed bottom-20 md:bottom-0 left-0 right-0 z-[100] transition-all duration-300 ${
      isFullScreen ? 'fixed inset-0 h-screen bg-black flex flex-col items-center justify-center p-6' : `h-44 md:h-24 ${bgColor} backdrop-blur-2xl border-t ${borderColor} px-4 md:px-6 flex flex-col items-center justify-center md:flex-row md:justify-between`
    }`}>
      {isFullScreen && (
        <button onClick={() => setIsFullScreen(false)} className="absolute top-8 right-8 text-white p-2 hover:bg-white/10 rounded-full transition-colors">
          <Minimize2 size={32} />
        </button>
      )}

      <div className={`${isFullScreen ? 'w-[80%] max-w-2xl mb-8' : 'w-full md:absolute md:top-0 md:left-0 md:right-0 px-4 md:px-0 mb-2 md:mb-0'}`}>
         <div className="flex items-center gap-3 w-full group">
            <span className={`text-[10px] font-bold ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'} w-10 md:hidden`}>{formatTime(currentTime)}</span>
            <div className="relative flex-1 h-8 flex items-center">
              <input 
                type="range" min="0" max={duration || 100} step="0.1" value={currentTime}
                onChange={handleProgressChange}
                className="w-full h-1 md:h-1.5 rounded-full appearance-none cursor-pointer accent-blue-600 bg-gray-400/20 hover:bg-gray-400/40 transition-all [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-600"
              />
            </div>
            <span className={`text-[10px] font-bold ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'} w-10 text-right md:hidden`}>{formatTime(duration)}</span>
         </div>
      </div>

      <div className={`w-full flex items-center justify-between gap-2 md:gap-0 ${isFullScreen ? 'flex-col flex-1 justify-center' : ''}`}>
        <div className={`flex items-center gap-3 md:gap-4 ${isFullScreen ? 'flex-col mb-12' : 'hidden md:flex w-[25%] overflow-hidden'}`}>
          <img src={currentSong.coverUrl} alt={currentSong.title} className={`rounded-lg md:rounded-2xl shadow-lg object-cover transition-all ${isFullScreen ? 'w-80 h-80' : 'w-16 h-16'}`} />
          <div className={isFullScreen ? 'text-center mt-6' : 'overflow-hidden flex-1'}>
            <div className={`font-bold truncate ${isFullScreen ? 'text-4xl mb-2 text-white' : `text-sm ${textColor}`}`}>{currentSong.title}</div>
            <div className={`font-medium ${isFullScreen ? 'text-xl text-gray-400' : 'text-xs text-gray-500 truncate'}`}>{currentSong.artist}</div>
          </div>
        </div>

        {!isFullScreen && (
          <div className="md:hidden flex items-center gap-2 w-[20%] overflow-hidden">
            <img src={currentSong.coverUrl} className="w-10 h-10 rounded-lg object-cover shadow-md" />
          </div>
        )}

        <div className={`flex flex-col items-center gap-1 md:gap-2 ${isFullScreen ? 'w-full' : 'flex-1 md:max-w-[45%]'}`}>
          <div className="flex items-center justify-center gap-5 sm:gap-6 md:gap-8 w-full">
            <button onClick={onToggleShuffle} className={`p-2 transition-all active:scale-75 ${isShuffle ? 'text-blue-500' : 'text-gray-400'}`}><Shuffle size={isFullScreen ? 32 : 18} /></button>
            <button onClick={onBack} className={`p-2 cursor-pointer transition-all active:scale-75 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}><SkipBack size={isFullScreen ? 40 : 24} fill="currentColor" /></button>
            <button onClick={onTogglePlay} className={`rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-90 shadow-2xl ${theme === 'dark' ? 'bg-white text-black' : 'bg-gray-900 text-white'} ${isFullScreen ? 'w-24 h-24' : 'w-12 h-12 md:w-14 md:h-14'}`}>{isPlaying ? <Pause fill="currentColor" size={isFullScreen ? 40 : 26} /> : <Play fill="currentColor" size={isFullScreen ? 40 : 26} className="ml-1" />}</button>
            <button onClick={onNext} className={`p-2 cursor-pointer transition-all active:scale-75 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}><SkipForward size={isFullScreen ? 40 : 24} fill="currentColor" /></button>
            <button onClick={onToggleRepeat} className={`p-2 transition-all active:scale-75 ${repeatMode !== 'none' ? 'text-blue-500' : 'text-gray-400'}`}>{repeatMode === 'one' ? <Repeat1 size={isFullScreen ? 32 : 18} /> : <Repeat size={isFullScreen ? 32 : 18} />}</button>
          </div>
          <div className="hidden md:flex w-full items-center justify-center gap-3 text-[10px] font-bold text-gray-400"><span>{formatTime(currentTime)} / {formatTime(duration)}</span></div>
        </div>

        <div className={`flex items-center gap-2 md:gap-4 justify-end ${isFullScreen ? 'w-full mt-12 px-10' : 'w-[25%] md:w-[25%]'}`}>
          <button onClick={onDownload} className="text-gray-400 hover:text-green-500 transition-colors p-2"><Download size={20} /></button>
          <div className="hidden sm:flex items-center gap-2 md:gap-3 flex-1 justify-end max-w-[140px]">
            <button onClick={toggleMute} className="text-gray-400 hover:text-blue-500 transition-colors p-1">{isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}</button>
            <input type="range" min="0" max="100" value={volume} onChange={handleVolumeChange} className={`w-12 md:w-full h-1 rounded-full appearance-none cursor-pointer ${theme === 'dark' ? 'bg-white/10 accent-white' : 'bg-gray-200 accent-gray-900'}`} />
          </div>
          {!isFullScreen && <button onClick={() => setIsFullScreen(true)} className="text-gray-400 hover:text-blue-500 transition-colors p-2"><Maximize2 size={20} /></button>}
        </div>
      </div>
    </div>
  );
};
