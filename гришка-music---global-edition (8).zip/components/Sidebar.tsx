
import React from 'react';
import { Home, Compass, Library, Plus, ListMusic } from 'lucide-react';
import { Translations, Theme, Playlist } from '../types';

interface SidebarProps {
  t: Translations;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  theme: Theme;
  playlists: Playlist[];
  onCreatePlaylist: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ t, activeTab, setActiveTab, theme, playlists, onCreatePlaylist }) => {
  const menuItems = [
    { id: 'home', icon: Home, label: t.home },
    { id: 'explore', icon: Compass, label: t.explore },
    { id: 'library', icon: Library, label: t.library },
  ];

  const bgColor = theme === 'dark' ? 'bg-[#000000]' : 'bg-gray-50';
  const borderColor = theme === 'dark' ? 'border-white/10' : 'border-gray-200';
  const textColor = theme === 'dark' ? 'text-white' : 'text-gray-900';

  return (
    <div className={`w-72 h-screen flex flex-col border-r transition-all duration-300 ${bgColor} ${borderColor} hidden md:flex shrink-0`}>
      <div className="p-10 flex items-center">
        <h1 className={`text-2xl font-black tracking-tighter ${textColor}`}>
          Гришка <span className="text-blue-600">Music</span>
        </h1>
      </div>

      <nav className="flex-1 px-5 space-y-2 mt-4 overflow-y-auto custom-scrollbar">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-5 px-6 py-4 rounded-3xl transition-all duration-300 ${
              activeTab === item.id 
                ? (theme === 'dark' ? 'bg-white/10 text-white font-black' : 'bg-blue-600 text-white font-black shadow-xl shadow-blue-500/30') 
                : (theme === 'dark' ? 'text-gray-500 hover:bg-white/5 hover:text-white' : 'text-gray-500 hover:bg-white hover:text-gray-900 hover:shadow-sm')
            }`}
          >
            <item.icon size={22} strokeWidth={activeTab === item.id ? 3 : 2} />
            <span className="text-lg font-bold tracking-tight">{item.label}</span>
          </button>
        ))}

        <div className="pt-8 pb-4 px-6 flex items-center justify-between">
          <p className="text-[11px] font-black text-gray-500 uppercase tracking-[0.3em]">{t.playlists}</p>
          <button 
            onClick={onCreatePlaylist}
            className={`p-1.5 rounded-full hover:bg-blue-500/10 text-blue-500 transition-colors`}
          >
            <Plus size={16} strokeWidth={3} />
          </button>
        </div>

        <div className="space-y-1">
          {playlists.map(p => (
            <button
              key={p.id}
              onClick={() => setActiveTab(`playlist-${p.id}`)}
              className={`w-full flex items-center gap-4 px-6 py-3 rounded-2xl transition-all ${
                activeTab === `playlist-${p.id}` 
                  ? 'text-blue-500 font-black bg-blue-500/5' 
                  : 'text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-white/5'
              }`}
            >
              <ListMusic size={18} />
              <span className="text-sm font-bold truncate">{p.name}</span>
            </button>
          ))}
        </div>
      </nav>

      <div className={`p-10 border-t ${theme === 'dark' ? 'border-white/5' : 'border-gray-100'}`}>
        <p className="text-[10px] text-gray-500 text-center font-black uppercase tracking-widest">Гришка Music Platform</p>
      </div>
    </div>
  );
};