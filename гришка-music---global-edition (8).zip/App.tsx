
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Player } from './components/Player';
import { MusicCard } from './components/MusicCard';
import { Settings } from './components/Settings';
import { UploadModal } from './components/UploadModal';
import { CreatePlaylistModal } from './components/CreatePlaylistModal';
import { PlaylistSelectModal } from './components/PlaylistSelectModal';
import { VoiceSearchOverlay } from './components/VoiceSearchOverlay';
import { MobileNav } from './components/MobileNav';
import { Song, Language, Theme, RepeatMode, Playlist } from './types';
import { translations } from './i18n';
import { Sparkles, Plus, AlertCircle, ListMusic, Music, SearchX, ArrowLeft } from 'lucide-react';

// Вспомогательные функции для Cookies
const setCookie = (name: string, value: string, days: number) => {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + expires + '; path=/';
};

const getCookie = (name: string) => {
  return document.cookie.split('; ').reduce((r, v) => {
    const parts = v.split('=');
    return parts[0] === name ? decodeURIComponent(parts[1]) : r;
  }, '');
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  
  const getInitialLanguage = (): Language => {
    const savedLang = getCookie('gm_lang') as Language;
    if (savedLang) return savedLang;
    const browserLang = navigator.language.toLowerCase();
    return (browserLang.startsWith('ru') || browserLang.startsWith('be') || browserLang.startsWith('uk')) ? 'ru' : 'en';
  };

  const getInitialTheme = (): Theme => {
    return (getCookie('gm_theme') as Theme) || 'dark';
  };

  const [language, setLanguage] = useState<Language>(getInitialLanguage());
  const [theme, setTheme] = useState<Theme>(getInitialTheme());
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);
  const [songToAddToPlaylist, setSongToAddToPlaylist] = useState<Song | null>(null);
  const [isVoiceSearchOpen, setIsVoiceSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<Song[]>([]);
  
  const [globalMusic, setGlobalMusic] = useState<Song[]>(() => {
    try {
      const saved = localStorage.getItem('gm_global_v9');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    try {
      const saved = localStorage.getItem('gm_playlists_v9');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('none');
  const [isShuffle, setIsShuffle] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const t = translations[language];

  // Сохранение и Cookies
  useEffect(() => {
    try {
      localStorage.setItem('gm_global_v9', JSON.stringify(globalMusic));
    } catch (e) {
      console.warn("Storage quota exceeded. Using memory only.");
    }
  }, [globalMusic]);

  useEffect(() => {
    try {
      localStorage.setItem('gm_playlists_v9', JSON.stringify(playlists));
    } catch (e) {}
  }, [playlists]);

  useEffect(() => {
    setCookie('gm_theme', theme, 30);
    setCookie('gm_lang', language, 30);
    document.body.style.backgroundColor = theme === 'dark' ? '#030303' : '#ffffff';
    document.body.style.color = theme === 'dark' ? '#ffffff' : '#030303';
  }, [theme, language]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setResults([]);
      if (activeTab === 'search') setActiveTab('home');
      return;
    }
    
    if (activeTab !== 'search') setActiveTab('search');
    const lowerQuery = query.toLowerCase();
    const filtered = globalMusic.filter(s => 
      s.title.toLowerCase().startsWith(lowerQuery) || 
      s.artist.toLowerCase().startsWith(lowerQuery) ||
      s.title.toLowerCase().includes(lowerQuery)
    );
    setResults(filtered);
  };

  const handlePlaySong = (song: Song) => {
    if (currentSong?.id === song.id) {
      if (audioRef.current) {
        if (isPlaying) audioRef.current.pause();
        else audioRef.current.play();
        setIsPlaying(!isPlaying);
      }
    } else {
      setCurrentSong(song);
      setIsPlaying(true);
      if (audioRef.current) {
        audioRef.current.src = song.audioUrl;
        audioRef.current.play().catch(() => setIsPlaying(false));
      }
    }
  };

  const handleDownload = (song: Song) => {
    const link = document.createElement('a');
    link.href = song.audioUrl;
    link.download = `${song.artist} - ${song.title}.mp3`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getCurrentQueue = useCallback(() => {
    if (activeTab === 'search') return results;
    if (activeTab.startsWith('playlist-')) {
      const pId = activeTab.replace('playlist-', '');
      return playlists.find(p => p.id === pId)?.songs || [];
    }
    return globalMusic;
  }, [activeTab, results, playlists, globalMusic]);

  const playNext = useCallback(() => {
    const queue = getCurrentQueue();
    if (!currentSong || queue.length === 0) return;
    let nextIndex;
    if (isShuffle) {
      nextIndex = Math.floor(Math.random() * queue.length);
    } else {
      const currentIndex = queue.findIndex(s => s.id === currentSong.id);
      nextIndex = (currentIndex + 1) % queue.length;
    }
    handlePlaySong(queue[nextIndex]);
  }, [currentSong, isShuffle, getCurrentQueue]);

  const playPrevious = useCallback(() => {
    if (!audioRef.current || !currentSong) return;
    if (audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      audioRef.current.play();
      return;
    }
    const queue = getCurrentQueue();
    if (queue.length === 0) return;
    const currentIndex = queue.findIndex(s => s.id === currentSong.id);
    const prevIndex = (currentIndex - 1 + queue.length) % queue.length;
    handlePlaySong(queue[prevIndex]);
  }, [currentSong, getCurrentQueue]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const handleEnded = () => {
      if (repeatMode === 'one') {
        audio.currentTime = 0;
        audio.play();
      } else {
        playNext();
      }
    };
    audio.addEventListener('ended', handleEnded);
    return () => audio.removeEventListener('ended', handleEnded);
  }, [repeatMode, playNext]);

  const handleCreatePlaylist = (newPlaylist: Playlist) => {
    setPlaylists(prev => [...prev, newPlaylist]);
    setIsCreatePlaylistOpen(false);
  };

  const handleSelectPlaylistForSong = (playlistId: string) => {
    if (!songToAddToPlaylist) return;
    const song = songToAddToPlaylist;
    setPlaylists(prev => {
      const updated = [...prev];
      const idx = updated.findIndex(p => p.id === playlistId);
      if (idx !== -1) {
        const updatedPlaylist = { ...updated[idx], songs: [...updated[idx].songs] };
        if (!updatedPlaylist.songs.some(s => s.id === song.id)) {
          updatedPlaylist.songs.push(song);
          updated[idx] = updatedPlaylist;
        }
      }
      return updated;
    });
    setSongToAddToPlaylist(null);
  };

  const renderSongsGrid = (songs: Song[]) => (
    <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 md:gap-5">
      {songs.map((song) => (
        <MusicCard 
          key={song.id} 
          song={song} 
          onPlay={handlePlaySong} 
          onDownload={handleDownload}
          onAddToPlaylist={(s) => setSongToAddToPlaylist(s)}
          theme={theme} 
        />
      ))}
    </div>
  );

  const renderContent = () => {
    if (activeTab.startsWith('playlist-')) {
      const pId = activeTab.replace('playlist-', '');
      const playlist = playlists.find(p => p.id === pId);
      if (!playlist) { setActiveTab('home'); return null; }

      return (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8">
            <div className={`w-40 h-40 md:w-56 md:h-56 rounded-[40px] flex items-center justify-center shadow-2xl ${theme === 'dark' ? 'bg-white/5' : 'bg-gray-100'}`}>
              {playlist.icon ? <img src={playlist.icon} className="w-full h-full object-cover rounded-[40px]" /> : <ListMusic size={80} className="text-blue-500" />}
            </div>
            <div className="text-center md:text-left space-y-2">
              <button onClick={() => setActiveTab('explore')} className="flex items-center gap-2 text-xs font-black text-blue-500 uppercase tracking-widest hover:opacity-80 transition-all mb-4">
                <ArrowLeft size={14} strokeWidth={3} /> {t.explore}
              </button>
              <h2 className="text-3xl md:text-6xl font-black uppercase tracking-tight">{playlist.name}</h2>
              <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">{playlist.songs.length} ТРЕКОВ</p>
            </div>
          </div>
          <div className="pt-6">{playlist.songs.length > 0 ? renderSongsGrid(playlist.songs) : <div className="p-16 text-center border-2 border-dashed border-gray-100 dark:border-white/5 rounded-[40px]"><Music size={40} className="mx-auto text-gray-400 mb-4" /><p className="text-gray-500 font-bold">{t.emptyLibrary}</p></div>}</div>
        </div>
      );
    }

    if (activeTab === 'home') {
      return (
        <div className="space-y-10">
          <section>
            <div className="flex items-center gap-2 mb-6 md:mb-8">
              <Sparkles size={20} className="text-blue-500" />
              <h2 className="text-lg md:text-2xl font-black uppercase tracking-tight">{t.newReleases}</h2>
            </div>
            {globalMusic.length === 0 ? <div className="flex flex-col items-center justify-center py-16 rounded-3xl border-2 border-dashed border-gray-100 dark:border-white/5"><AlertCircle size={40} className="text-gray-400 mb-4" /><p className="text-gray-400 font-bold text-sm">{t.beFirst}</p></div> : renderSongsGrid(globalMusic)}
          </section>
        </div>
      );
    }

    if (activeTab === 'explore') {
      return (
        <div className="space-y-10">
          <section>
            <h2 className="text-xl md:text-3xl font-black mb-6 md:mb-8 uppercase tracking-tight">{t.playlists}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {playlists.map(p => (
                <div key={p.id} onClick={() => setActiveTab(`playlist-${p.id}`)} className={`p-5 rounded-[40px] cursor-pointer transition-all border group ${theme === 'dark' ? 'bg-white/5 border-white/5 hover:bg-white/10' : 'bg-white border-gray-100 hover:border-blue-500 shadow-sm'}`}>
                  <div className="aspect-square rounded-3xl overflow-hidden mb-4 bg-black/20 flex items-center justify-center">
                    {p.icon ? <img src={p.icon} className="w-full h-full object-cover transition-transform group-hover:scale-110" /> : <ListMusic size={40} className="text-blue-500" />}
                  </div>
                  <h3 className="font-bold text-lg md:text-xl truncate">{p.name}</h3>
                  <p className="text-xs font-bold text-gray-500 mt-1 uppercase tracking-widest">{p.songs.length} треков</p>
                </div>
              ))}
              <button onClick={() => setIsCreatePlaylistOpen(true)} className={`p-5 rounded-[40px] border-2 border-dashed flex flex-col items-center justify-center gap-3 transition-all ${theme === 'dark' ? 'border-white/5 hover:border-blue-500 text-gray-500 hover:text-blue-500' : 'border-gray-100 hover:border-blue-500 text-gray-400 hover:text-blue-500'}`}><Plus size={32} /><span className="font-black text-xs uppercase tracking-widest">{t.createPlaylist}</span></button>
            </div>
          </section>
        </div>
      );
    }

    if (activeTab === 'library') {
      return (
        <div className="space-y-10">
          <h2 className="text-2xl md:text-4xl font-black mb-6 md:mb-10">{t.library}</h2>
          <section>
             <h3 className="text-xs md:text-xl font-black mb-4 md:mb-6 uppercase tracking-widest text-blue-500 flex items-center gap-2"><Music className="w-4 h-4 md:w-5 md:h-5" /> {t.myMusic}</h3>
             {globalMusic.length > 0 ? renderSongsGrid(globalMusic) : <div className="p-16 text-center text-gray-500 font-bold border-2 border-dashed border-gray-100 dark:border-white/5 rounded-[40px]">{t.emptyLibrary}</div>}
          </section>
        </div>
      );
    }

    if (activeTab === 'search') {
      return (
        <div className="space-y-6">
          <h2 className="text-xl md:text-3xl font-black">{t.resultsFor} "{searchQuery}"</h2>
          {results.length > 0 ? renderSongsGrid(results) : <div className="flex flex-col items-center justify-center py-24 text-center"><SearchX size={64} className="text-gray-500 mb-4 opacity-50" /><p className="text-xl font-bold text-gray-500">{t.noResults}</p></div>}
        </div>
      );
    }

    return null;
  };

  return (
    <div className={`flex h-screen overflow-hidden transition-colors duration-300 ${theme === 'dark' ? 'bg-[#030303] text-white' : 'bg-white text-gray-900'}`}>
      <audio ref={audioRef} onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} />
      <Sidebar t={t} activeTab={activeTab} setActiveTab={setActiveTab} theme={theme} playlists={playlists} onCreatePlaylist={() => setIsCreatePlaylistOpen(true)} />
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <Header t={t} theme={theme} searchQuery={searchQuery} setSearchQuery={setSearchQuery} onSearch={handleSearch} onOpenSettings={() => setIsSettingsOpen(true)} onToggleTheme={() => setTheme(prev => prev === 'dark' ? 'light' : 'dark')} onOpenVoiceSearch={() => setIsVoiceSearchOpen(true)} />
        <div className="flex-1 overflow-y-auto px-4 md:px-8 pb-72 md:pb-48">
          <div className="py-6 md:py-8 flex items-center justify-between">
             <button onClick={() => setIsUploadOpen(true)} className="flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full text-xs font-black transition-all shadow-md active:scale-95"><Plus size={16} strokeWidth={3} /> {t.upload}</button>
          </div>
          {renderContent() || <div className="flex items-center justify-center py-20"><p className="font-bold text-gray-500">Загрузка...</p></div>}
        </div>
        <Player currentSong={currentSong} isPlaying={isPlaying} onTogglePlay={() => handlePlaySong(currentSong!)} onDownload={() => currentSong && handleDownload(currentSong)} audioRef={audioRef} onNext={playNext} onBack={playPrevious} repeatMode={repeatMode} onToggleRepeat={() => setRepeatMode(prev => prev === 'none' ? 'all' : prev === 'all' ? 'one' : 'none')} isShuffle={isShuffle} onToggleShuffle={() => setIsShuffle(!isShuffle)} theme={theme} />
        <MobileNav t={t} activeTab={activeTab} setActiveTab={setActiveTab} onOpenSettings={() => setIsSettingsOpen(true)} theme={theme} />
      </main>
      {isSettingsOpen && <Settings t={t} theme={theme} user={null} currentLang={language} onClose={() => setIsSettingsOpen(false)} onLanguageChange={setLanguage} onThemeChange={setTheme} onLogout={() => {}} />}
      {isUploadOpen && <UploadModal t={t} theme={theme} onClose={() => setIsUploadOpen(false)} onUpload={(s) => setGlobalMusic(prev => [s, ...prev])} />}
      {isCreatePlaylistOpen && <CreatePlaylistModal t={t} theme={theme} onClose={() => setIsCreatePlaylistOpen(false)} onCreate={handleCreatePlaylist} />}
      {songToAddToPlaylist && <PlaylistSelectModal song={songToAddToPlaylist} playlists={playlists} t={t} theme={theme} onClose={() => setSongToAddToPlaylist(null)} onSelect={handleSelectPlaylistForSong} onCreateNew={() => setIsCreatePlaylistOpen(true)} />}
      {isVoiceSearchOpen && <VoiceSearchOverlay t={t} theme={theme} onClose={() => setIsVoiceSearchOpen(false)} onSearchResult={handleSearch} />}
    </div>
  );
};

export default App;
