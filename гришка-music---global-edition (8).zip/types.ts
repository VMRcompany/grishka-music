
export interface Review {
  id: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  duration: string;
  durationSec: number;
  audioUrl: string;
  genre?: string;
  tags?: string[];
  type?: 'song' | 'remix' | 'sfx';
  averageRating?: number;
  reviews?: Review[];
  publishedBy?: string;
  isPublic?: boolean;
  isUserUploaded?: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  icon?: string;
  isPublic: boolean;
  songs: Song[];
  createdAt: string;
}

export type Language = 'en' | 'ru';
export type Theme = 'light' | 'dark';
export type RepeatMode = 'none' | 'one' | 'all';

export interface Translations {
  home: string;
  explore: string;
  library: string;
  myMusic: string;
  searchPlaceholder: string;
  settings: string;
  language: string;
  upgrade: string;
  newReleases: string;
  quickPicks: string;
  recommended: string;
  likedSongs: string;
  selectLanguage: string;
  resultsFor: string;
  searching: string;
  rating: string;
  reviews: string;
  writeReview: string;
  submit: string;
  theme: string;
  light: string;
  dark: string;
  account: string;
  privacy: string;
  audioQuality: string;
  upload: string;
  uploadDesc: string;
  selectFile: string;
  publish: string;
  preview: string;
  beFirst: string;
  emptyLibrary: string;
  hashtags: string;
  createPlaylist: string;
  addToPlaylist: string;
  playlists: string;
  selectPlaylist: string;
  playlistName: string;
  playlistIcon: string;
  visibility: string;
  public: string;
  private: string;
  create: string;
  cancel: string;
  noResults: string;
  voiceSearchTitle: string;
  searchByMusic: string;
  listening: string;
  analyzing: string;
  searchByVoice: string;
}
