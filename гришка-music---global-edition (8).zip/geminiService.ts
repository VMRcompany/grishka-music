
import { GoogleGenAI, Type } from "@google/genai";
import { Song, Language } from "./types";

// Use process.env.API_KEY directly as specified in guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const songSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      title: { type: Type.STRING },
      artist: { type: Type.STRING },
      album: { type: Type.STRING },
      coverUrl: { type: Type.STRING },
      duration: { type: Type.STRING },
      durationSec: { type: Type.NUMBER },
      audioUrl: { type: Type.STRING },
      genre: { type: Type.STRING },
      type: { type: Type.STRING, enum: ['song', 'remix', 'sfx'] },
      averageRating: { type: Type.NUMBER }
    },
    required: ["id", "title", "artist", "album", "coverUrl", "duration", "durationSec"],
  },
};

export async function searchMusic(query: string, lang: Language): Promise<Song[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for REAL music existing in the world for query: "${query}". 
      Return the most accurate titles, artists, and high-quality cover art URLs. 
      Include original songs, professional remixes, and SFX. 
      For "funk", provide Phonk, Brazilian Funk, and classic Funk hits from 2024-2025.
      Output format: JSON. Language: ${lang}. Ensure durationSec is realistic.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: songSchema,
      },
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini Search Error:", error);
    return [];
  }
}

export async function getRecommendations(lang: Language): Promise<Song[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate 15 REAL global music recommendations. 
      Mix: Billboard Top Hits, Trending Phonk, Electronic Remixes, and HQ SFX. 
      Data must be real world metadata. Use ${lang}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: songSchema,
      },
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini Recommendations Error:", error);
    return [];
  }
}